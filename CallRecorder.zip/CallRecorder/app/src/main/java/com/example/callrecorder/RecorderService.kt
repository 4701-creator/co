package com.example.callrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.net.Uri
import android.os.Environment
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * خدمة تعمل بالمقدمة (Foreground Service) تراقب حالة الاتصال.
 * عند بدء المكالمة (OFFHOOK) تبدأ التسجيل من المايك، وعند انتهائها توقفه.
 * لازم السبيكر يكون مفتوح حتى يلتقط المايك صوت الطرف الثاني.
 */
class RecorderService : Service() {

    companion object {
        const val CHANNEL_ID = "call_recorder_channel"
        const val NOTIF_ID = 1
        const val RELATIVE_DIR = "Music/CallRecords"
        private const val TAG = "RecorderService"
    }

    private lateinit var telephony: TelephonyManager
    private var callback: CallCb? = null

    private var recorder: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var currentUri: Uri? = null

    private inner class CallCb : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) {
            when (state) {
                TelephonyManager.CALL_STATE_OFFHOOK -> startRecording()
                TelephonyManager.CALL_STATE_IDLE -> stopRecording()
                else -> Unit // الرنين: ننتظر الرد
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        telephony = getSystemService(TelephonyManager::class.java)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(
            NOTIF_ID,
            buildNotification("بانتظار مكالمة… فعّل السبيكر وقت المكالمة"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        if (callback == null) {
            try {
                val cb = CallCb()
                telephony.registerTelephonyCallback(mainExecutor, cb)
                callback = cb
            } catch (e: SecurityException) {
                Log.e(TAG, "READ_PHONE_STATE غير ممنوح", e)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startRecording() {
        if (recorder != null) return

        val name = "call_" +
            SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date()) + ".m4a"

        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, RELATIVE_DIR)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }

        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Log.e(TAG, "تعذر إنشاء الملف")
            return
        }

        try {
            val descriptor = contentResolver.openFileDescriptor(uri, "w")
                ?: throw IllegalStateException("openFileDescriptor رجع null")

            val r = MediaRecorder(this).apply {
                // VOICE_RECOGNITION: بدون إلغاء الصدى، حتى ما يختفي صوت السبيكر
                setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128_000)
                setOutputFile(descriptor.fileDescriptor)
                prepare()
                start()
            }

            pfd = descriptor
            recorder = r
            currentUri = uri
            updateNotification("🔴 جاري تسجيل المكالمة…")
        } catch (e: Exception) {
            Log.e(TAG, "فشل بدء التسجيل", e)
            cleanupFailed(uri)
        }
    }

    private fun stopRecording() {
        val r = recorder ?: return
        val uri = currentUri

        var ok = true
        try {
            r.stop()
        } catch (e: RuntimeException) {
            // يصير إذا انتهت المكالمة بسرعة قبل ما توصل بيانات
            ok = false
            Log.w(TAG, "stop فشل", e)
        }
        r.release()
        recorder = null

        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        currentUri = null

        if (uri != null) {
            if (ok) {
                val done = ContentValues().apply {
                    put(MediaStore.Audio.Media.IS_PENDING, 0)
                }
                contentResolver.update(uri, done, null, null)
            } else {
                contentResolver.delete(uri, null, null)
            }
        }
        updateNotification("بانتظار مكالمة… فعّل السبيكر وقت المكالمة")
    }

    private fun cleanupFailed(uri: Uri) {
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        currentUri = null
        contentResolver.delete(uri, null, null)
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "مسجل المكالمات",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("مسجل المكالمات")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        callback?.let { telephony.unregisterTelephonyCallback(it) }
        callback = null
        stopRecording()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
