package com.example.callrecorder

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private data class Rec(val uri: Uri, val name: String, val size: Long, val durationMs: Long)

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var list: ListView

    private var recs: List<Rec> = emptyList()
    private var player: MediaPlayer? = null

    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    private val needed = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.POST_NOTIFICATIONS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        status = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val hint = TextView(this).apply {
            text = "فعّل السبيكر وقت المكالمة حتى يلتقط المايك صوت الطرف الثاني.\n" +
                "بعد إعادة تشغيل الجهاز افتح التطبيق مرة وحدة وفعّل التسجيل."
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
        }
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        val header = TextView(this).apply {
            text = "التسجيلات (اضغط على تسجيل للخيارات)"
            textSize = 14f
            setPadding(0, pad, 0, pad / 2)
        }
        list = ListView(this).apply {
            setOnItemClickListener { _, _, pos, _ -> showOptions(recs[pos]) }
        }

        root.addView(status)
        root.addView(hint)
        root.addView(toggle)
        root.addView(header)
        root.addView(list, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
        refreshList()
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }

    private fun hasPermissions() = needed.all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    private fun onToggle() {
        if (prefs.getBoolean("enabled", false)) {
            stopService(Intent(this, RecorderService::class.java))
            prefs.edit().putBoolean("enabled", false).apply()
            refreshUi()
        } else if (hasPermissions()) {
            startRecorderService()
        } else {
            requestPermissions(needed, 1)
        }
    }

    private fun startRecorderService() {
        // لازم نبدأ الخدمة والتطبيق ظاهر على الشاشة (قيد أندرويد 14 للمايك)
        startForegroundService(Intent(this, RecorderService::class.java))
        prefs.edit().putBoolean("enabled", true).apply()
        refreshUi()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // الإشعارات اختيارية، الباقي إجباري
        val mandatoryOk = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE)
            .all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        if (mandatoryOk) {
            startRecorderService()
        } else {
            Toast.makeText(this, "لازم تمنح إذن المايك والهاتف", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshUi() {
        val on = prefs.getBoolean("enabled", false)
        status.text = if (on) "✅ التسجيل التلقائي شغال" else "⏸ التسجيل التلقائي متوقف"
        toggle.text = if (on) "إيقاف التسجيل التلقائي" else "تشغيل التسجيل التلقائي"
    }

    private fun refreshList() {
        val out = mutableListOf<Rec>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DURATION
        )
        contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            proj,
            "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?",
            arrayOf("${RecorderService.RELATIVE_DIR}%"),
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out += Rec(
                    ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                    c.getString(1) ?: "?",
                    c.getLong(2),
                    c.getLong(3)
                )
            }
        }
        recs = out
        val labels = out.map {
            "${it.name}\n${fmtDuration(it.durationMs)}  •  ${it.size / 1024} KB"
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
    }

    private fun fmtDuration(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun showOptions(rec: Rec) {
        AlertDialog.Builder(this)
            .setTitle(rec.name)
            .setItems(arrayOf("تشغيل / إيقاف", "مشاركة", "حذف")) { _, which ->
                when (which) {
                    0 -> togglePlayback(rec)
                    1 -> share(rec)
                    2 -> confirmDelete(rec)
                }
            }
            .show()
    }

    private fun togglePlayback(rec: Rec) {
        if (player?.isPlaying == true) {
            stopPlayback()
            return
        }
        stopPlayback()
        try {
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, rec.uri)
                prepare()
                setOnCompletionListener { stopPlayback() }
                start()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر التشغيل", Toast.LENGTH_SHORT).show()
            stopPlayback()
        }
    }

    private fun stopPlayback() {
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun share(rec: Rec) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "audio/mp4"
            putExtra(Intent.EXTRA_STREAM, rec.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "مشاركة التسجيل"))
    }

    private fun confirmDelete(rec: Rec) {
        AlertDialog.Builder(this)
            .setMessage("حذف هذا التسجيل نهائياً؟")
            .setPositiveButton("حذف") { _, _ ->
                stopPlayback()
                try {
                    contentResolver.delete(rec.uri, null, null)
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر الحذف", Toast.LENGTH_SHORT).show()
                }
                refreshList()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
